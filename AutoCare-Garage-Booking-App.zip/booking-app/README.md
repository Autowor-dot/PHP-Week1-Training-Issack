# AutoCare Garage — PHP Service Booking App

A small plain-PHP service-business application built for the Week 1 OOP and JSON project.

## Features

- Home page with customer and booking counts
- Customer registration with name, email and phone validation
- Service booking with customer selection, service selection, date validation and optional notes
- Bookings list showing customer, service, date, price and status
- JSON file persistence (no database or framework)
- Four classes: `JsonStorage`, `Customer`, `Service`, and `Booking`
- Shared header and footer includes
- Friendly validation messages and escaped HTML output

## Requirements

- PHP 8.1 or newer
- A web browser
- No Composer, database or third-party packages required

The project uses PHP 8 features including constructor property promotion and `never` return types.

## Run locally

1. Download or clone this repository.
2. Open a terminal in the `booking-app` folder.
3. Start PHP's built-in development server:

   ```bash
   php -S localhost:8000
   ```

4. Open <http://localhost:8000> in your browser.
5. Register a customer, book a service, then open the Bookings page.

If your terminal is currently in the parent `week-01` folder, run:

```bash
cd booking-app
php -S localhost:8000
```

## Project structure

```text
booking-app/
├── assets/
│   └── style.css
├── classes/
│   ├── Booking.php
│   ├── Customer.php
│   ├── JsonStorage.php
│   └── Service.php
├── includes/
│   ├── bootstrap.php
│   ├── footer.php
│   └── header.php
├── storage/
│   ├── .htaccess
│   ├── bookings.json
│   └── customers.json
├── book.php
├── bookings.php
├── index.php
├── register.php
└── README.md
```

## Data storage

Customer records are stored in `storage/customers.json`. Booking records are stored in `storage/bookings.json`. Both files start as empty JSON arrays. The PHP process must have permission to write to the `storage` directory.

The `.htaccess` file blocks direct access to the storage folder when the project is served by Apache. PHP's built-in server does not process `.htaccess`; do not use this learning project to store real customer information on a publicly exposed server.

## Validation and safety notes

- Server-side validation is performed in PHP.
- Email addresses are checked with `FILTER_VALIDATE_EMAIL`.
- Phone numbers are checked against a simple allowed-character pattern.
- User-provided text is escaped with `htmlspecialchars()` when rendered in HTML.
- JSON writes use `LOCK_EX`.
- This is a learning project, not a production booking system. A production system should add authentication, authorization, CSRF protection, stronger concurrency handling, backups and a database.

## Suggested six meaningful commits

Make these as separate commits as you build or upload the project in stages:

1. `Create project structure and shared layout`
2. `Add JSON storage class and initial data files`
3. `Add customer registration with validation`
4. `Add service catalog and booking classes`
5. `Build booking form and bookings list`
6. `Add responsive styling and project documentation`

Each commit should contain the files for that stage. Do not create six empty commits just to satisfy the requirement.
