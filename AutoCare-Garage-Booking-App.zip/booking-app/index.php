<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Home';
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
    <p class="eyebrow">AUTOCARE GARAGE</p>
    <h1>Reliable vehicle care, made simple.</h1>
    <p>Register your details, choose a service and keep track of your garage bookings in one place.</p>
    <div class="actions">
        <a class="button" href="register.php">Register customer</a>
        <a class="button button-light" href="book.php">Book a service</a>
    </div>
</section>
<section class="stats">
    <article class="panel"><span class="stat-number"><?= count($customerStore->all()) ?></span><span>Registered customers</span></article>
    <article class="panel"><span class="stat-number"><?= count($bookingStore->all()) ?></span><span>Bookings received</span></article>
</section>
<section class="panel intro">
    <h2>How it works</h2>
    <div class="steps">
        <div><strong>01</strong><h3>Register</h3><p>Add your name and contact information.</p></div>
        <div><strong>02</strong><h3>Choose a service</h3><p>Select the garage service and preferred date.</p></div>
        <div><strong>03</strong><h3>Track bookings</h3><p>View the bookings submitted to the garage.</p></div>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
