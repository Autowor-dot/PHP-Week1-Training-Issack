<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Book a service';
$errors = [];
$values = ['customer_id' => '', 'service' => '', 'date' => '', 'notes' => ''];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($values as $key => $_) {
        $values[$key] = trim($_POST[$key] ?? '');
    }
    $result = $bookingService->create($values);
    if ($result['success']) {
        $success = true;
        $values = ['customer_id' => '', 'service' => '', 'date' => '', 'notes' => ''];
    } else {
        $errors = $result['errors'];
    }
}
$customers = $customerService->all();
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading"><p class="eyebrow">SERVICE APPOINTMENT</p><h1>Book a service</h1><p>Choose a customer, service and preferred date.</p></div>
<?php if ($success): ?><div class="alert success">Your booking has been saved. Thank you!</div><?php endif; ?>
<?php if (isset($errors['general'])): ?><div class="alert error"><?= e($errors['general']) ?></div><?php endif; ?>
<?php if (!$customers): ?>
    <div class="alert info">There are no registered customers yet. <a href="register.php">Register a customer first</a>, then return here.</div>
<?php else: ?>
<form class="panel form-card" method="POST" action="book.php" novalidate>
    <div class="field"><label for="customer_id">Customer</label><select id="customer_id" name="customer_id" required><option value="">Select customer</option><?php foreach ($customers as $customer): ?><option value="<?= e($customer['id']) ?>" <?= $values['customer_id'] === $customer['id'] ? 'selected' : '' ?>><?= e($customer['name']) ?> — <?= e($customer['email']) ?></option><?php endforeach; ?></select><?= isset($errors['customer_id']) ? '<small class="field-error">'.e($errors['customer_id']).'</small>' : '' ?></div>
    <div class="field"><label for="service">Service</label><select id="service" name="service" required><option value="">Choose a service</option><?php foreach ($serviceCatalog->all() as $code => $service): ?><option value="<?= e($code) ?>" <?= $values['service'] === $code ? 'selected' : '' ?>><?= e($service['name']) ?> — TSh <?= number_format($service['price']) ?></option><?php endforeach; ?></select><?= isset($errors['service']) ? '<small class="field-error">'.e($errors['service']).'</small>' : '' ?></div>
    <div class="field"><label for="date">Preferred date</label><input id="date" type="date" name="date" min="<?= date('Y-m-d') ?>" value="<?= e($values['date']) ?>" required><?= isset($errors['date']) ? '<small class="field-error">'.e($errors['date']).'</small>' : '' ?></div>
    <div class="field"><label for="notes">Additional notes <span class="muted">(optional)</span></label><textarea id="notes" name="notes" rows="4" maxlength="500" placeholder="Tell us briefly about your vehicle or request..."><?= e($values['notes']) ?></textarea><?= isset($errors['notes']) ? '<small class="field-error">'.e($errors['notes']).'</small>' : '' ?></div>
    <button class="button" type="submit">Save booking</button>
</form>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
