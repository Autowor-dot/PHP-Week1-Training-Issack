<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Bookings';
$bookings = $bookingService->all();
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading page-heading-row"><div><p class="eyebrow">APPOINTMENT RECORDS</p><h1>Service bookings</h1><p>All bookings saved by this application.</p></div><a class="button" href="book.php">+ New booking</a></div>
<?php if (!$bookings): ?>
    <div class="panel empty-state"><h2>No bookings yet</h2><p>When a customer books a service, the record will appear here.</p><a href="book.php">Create the first booking</a></div>
<?php else: ?>
    <div class="panel table-wrap"><table><thead><tr><th>Customer</th><th>Service</th><th>Date</th><th>Price</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($bookings as $booking): ?><tr><td><strong><?= e($booking['customer_name']) ?></strong><small><?= e($booking['customer_email']) ?></small></td><td><?= e($booking['service_name']) ?><?php if ($booking['notes'] !== ''): ?><small><?= e($booking['notes']) ?></small><?php endif; ?></td><td><?= e($booking['date']) ?></td><td>TSh <?= number_format((int)$booking['price']) ?></td><td><span class="status"><?= e($booking['status']) ?></span></td></tr><?php endforeach; ?>
    </tbody></table></div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
