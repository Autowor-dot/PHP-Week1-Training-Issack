<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../classes/JsonStorage.php';
require_once __DIR__ . '/../classes/Customer.php';
require_once __DIR__ . '/../classes/Service.php';
require_once __DIR__ . '/../classes/Booking.php';

$customerStore = new JsonStorage(__DIR__ . '/../storage/customers.json');
$bookingStore = new JsonStorage(__DIR__ . '/../storage/bookings.json');
$customerService = new Customer($customerStore);
$serviceCatalog = new Service();
$bookingService = new Booking($bookingStore, $customerStore, $serviceCatalog);

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}
