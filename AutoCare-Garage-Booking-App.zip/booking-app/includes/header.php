<?php
$pageTitle = $pageTitle ?? 'AutoCare Garage';
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | AutoCare Garage</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="site-header">
    <a class="brand" href="index.php"><span class="brand-mark">A</span><span>AutoCare <small>GARAGE</small></span></a>
    <nav>
        <a class="<?= $currentPage === 'index.php' ? 'active' : '' ?>" href="index.php">Home</a>
        <a class="<?= $currentPage === 'register.php' ? 'active' : '' ?>" href="register.php">Register</a>
        <a class="<?= $currentPage === 'book.php' ? 'active' : '' ?>" href="book.php">Book service</a>
        <a class="<?= $currentPage === 'bookings.php' ? 'active' : '' ?>" href="bookings.php">Bookings</a>
    </nav>
</header>
<main class="container">
