</main>
<footer class="site-footer">
    <div><strong>AutoCare Garage</strong><p>Simple vehicle servicing and booking management.</p></div>
    <span>&copy; <?= date('Y') ?> AutoCare Garage · Week 1 PHP project</span>
</footer>
</body>
</html>
