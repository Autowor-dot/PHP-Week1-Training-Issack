<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Register customer';
$errors = [];
$values = ['name' => '', 'email' => '', 'phone' => ''];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($values as $key => $_) {
        $values[$key] = trim($_POST[$key] ?? '');
    }
    $result = $customerService->register($values);
    if ($result['success']) {
        $success = true;
        $values = ['name' => '', 'email' => '', 'phone' => ''];
    } else {
        $errors = $result['errors'];
    }
}
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading"><p class="eyebrow">CUSTOMER DETAILS</p><h1>Register a customer</h1><p>Add a customer before creating a service booking.</p></div>
<?php if ($success): ?><div class="alert success">Customer registered successfully. You can now book a service.</div><?php endif; ?>
<?php if (isset($errors['general'])): ?><div class="alert error"><?= e($errors['general']) ?></div><?php endif; ?>
<form class="panel form-card" method="POST" action="register.php" novalidate>
    <div class="field"><label for="name">Full name</label><input id="name" name="name" value="<?= e($values['name']) ?>" maxlength="80" required><?= isset($errors['name']) ? '<small class="field-error">'.e($errors['name']).'</small>' : '' ?></div>
    <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="<?= e($values['email']) ?>" required><?= isset($errors['email']) ? '<small class="field-error">'.e($errors['email']).'</small>' : '' ?></div>
    <div class="field"><label for="phone">Phone number</label><input id="phone" type="tel" name="phone" value="<?= e($values['phone']) ?>" placeholder="e.g. 0712345678" required><?= isset($errors['phone']) ? '<small class="field-error">'.e($errors['phone']).'</small>' : '' ?></div>
    <button class="button" type="submit">Register customer</button>
</form>
<?php require __DIR__ . '/includes/footer.php'; ?>
