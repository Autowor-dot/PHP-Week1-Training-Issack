# Suggested Git commit plan

The project is already provided as a complete working snapshot. The six commits below describe a meaningful build history to follow if you create the repository from the beginning or stage the files in batches.

1. Project skeleton: `index.php`, `includes/header.php`, `includes/footer.php`, `assets/style.css`, README initial structure.
2. JSON persistence: `classes/JsonStorage.php`, `storage/customers.json`, `storage/bookings.json`.
3. Customer management: `classes/Customer.php`, `register.php`.
4. Service and booking logic: `classes/Service.php`, `classes/Booking.php`.
5. Booking interface: `book.php`, `bookings.php`.
6. Integration and documentation: `includes/bootstrap.php`, final README, styling and fixes.

If you upload the complete ZIP in one GitHub web upload, that creates one commit, not six. To meet the six-commit requirement, use Git locally and commit each stage as described above, or upload/stage the groups separately through GitHub's web interface with a separate commit each time.
