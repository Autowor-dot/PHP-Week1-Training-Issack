<?php
declare(strict_types=1);

class Service
{
    private array $services = [
        'oil-change' => ['name' => 'Engine oil change', 'price' => 45000],
        'tyre-check' => ['name' => 'Tyre inspection', 'price' => 20000],
        'brake-service' => ['name' => 'Brake inspection', 'price' => 35000],
        'engine-diagnostic' => ['name' => 'Engine diagnostics', 'price' => 60000],
        'full-service' => ['name' => 'Full vehicle service', 'price' => 120000]
    ];

    public function all(): array
    {
        return $this->services;
    }

    public function find(string $code): ?array
    {
        return $this->services[$code] ?? null;
    }
}
