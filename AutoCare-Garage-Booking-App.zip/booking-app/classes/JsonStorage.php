<?php
declare(strict_types=1);

class JsonStorage
{
    public function __construct(private string $filePath)
    {
        $directory = dirname($this->filePath);
        if (!is_dir($directory)) {
            mkdir($directory, 0775, true);
        }
        if (!file_exists($this->filePath)) {
            file_put_contents($this->filePath, "[]", LOCK_EX);
        }
    }

    public function all(): array
    {
        $contents = file_get_contents($this->filePath);
        if ($contents === false || trim($contents) === '') {
            return [];
        }

        $records = json_decode($contents, true);
        return is_array($records) ? $records : [];
    }

    public function add(array $record): bool
    {
        $records = $this->all();
        $records[] = $record;
        $json = json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        if ($json === false) {
            return false;
        }

        return file_put_contents($this->filePath, $json, LOCK_EX) !== false;
    }
}
