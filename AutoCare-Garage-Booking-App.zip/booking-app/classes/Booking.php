<?php
declare(strict_types=1);

class Booking
{
    public function __construct(
        private JsonStorage $bookingStorage,
        private JsonStorage $customerStorage,
        private Service $serviceCatalog
    ) {}

    public function all(): array
    {
        $bookings = $this->bookingStorage->all();
        usort($bookings, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
        return $bookings;
    }

    public function create(array $input): array
    {
        $customerId = trim($input['customer_id'] ?? '');
        $serviceCode = trim($input['service'] ?? '');
        $date = trim($input['date'] ?? '');
        $notes = trim($input['notes'] ?? '');
        $errors = [];

        $customer = null;
        foreach ($this->customerStorage->all() as $item) {
            if ($item['id'] === $customerId) {
                $customer = $item;
                break;
            }
        }

        if (!$customer) {
            $errors['customer_id'] = 'Please select a registered customer.';
        }

        $service = $this->serviceCatalog->find($serviceCode);
        if (!$service) {
            $errors['service'] = 'Please choose one of the available services.';
        }

        $dateObject = DateTime::createFromFormat('Y-m-d', $date);
        $today = new DateTime('today');
        if (!$dateObject || $dateObject->format('Y-m-d') !== $date || $dateObject < $today) {
            $errors['date'] = 'Choose a valid date today or in the future.';
        }

        if (mb_strlen($notes) > 500) {
            $errors['notes'] = 'Notes must be 500 characters or fewer.';
        }

        if ($errors) {
            return ['success' => false, 'errors' => $errors];
        }

        $booking = [
            'id' => bin2hex(random_bytes(5)),
            'customer_id' => $customer['id'],
            'customer_name' => $customer['name'],
            'customer_email' => $customer['email'],
            'service_code' => $serviceCode,
            'service_name' => $service['name'],
            'price' => $service['price'],
            'date' => $date,
            'notes' => $notes,
            'status' => 'Pending',
            'created_at' => date('Y-m-d H:i:s')
        ];

        if (!$this->bookingStorage->add($booking)) {
            return ['success' => false, 'errors' => ['general' => 'We could not save this booking. Please try again.']];
        }

        return ['success' => true, 'booking' => $booking];
    }
}
