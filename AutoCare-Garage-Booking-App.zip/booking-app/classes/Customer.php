<?php
declare(strict_types=1);

class Customer
{
    public function __construct(private JsonStorage $storage) {}

    public function all(): array
    {
        return $this->storage->all();
    }

    public function findByEmail(string $email): ?array
    {
        foreach ($this->all() as $customer) {
            if (strtolower($customer['email']) === strtolower($email)) {
                return $customer;
            }
        }
        return null;
    }

    public function register(array $input): array
    {
        $name = trim($input['name'] ?? '');
        $email = trim($input['email'] ?? '');
        $phone = trim($input['phone'] ?? '');
        $errors = [];

        if ($name === '' || mb_strlen($name) < 2) {
            $errors['name'] = 'Please enter your name (at least 2 characters).';
        } elseif (mb_strlen($name) > 80) {
            $errors['name'] = 'Your name must be 80 characters or fewer.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Please enter a valid email address.';
        } elseif ($this->findByEmail($email)) {
            $errors['email'] = 'This email is already registered. Please use another email.';
        }

        if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) {
            $errors['phone'] = 'Enter a valid phone number (7–20 characters).';
        }

        if ($errors) {
            return ['success' => false, 'errors' => $errors];
        }

        $customer = [
            'id' => bin2hex(random_bytes(5)),
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'created_at' => date('Y-m-d H:i:s')
        ];

        if (!$this->storage->add($customer)) {
            return ['success' => false, 'errors' => ['general' => 'We could not save your details. Please try again.']];
        }

        return ['success' => true, 'customer' => $customer];
    }
}
